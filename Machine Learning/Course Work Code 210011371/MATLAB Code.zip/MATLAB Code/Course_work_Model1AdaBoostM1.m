% Model 1 Classification ensemble model- AdaboostM1 implementation for imbalanced classification
%Run in cell
%% Load dataset
close all; clear all; clc;
ds = readtable('Bank Marketing clean data preprocessed Final.csv','PreserveVariableNames',true);
%%
%Test train split
n= size(ds,1);
cv = cvpartition(n,'Holdout',0.3);
idx= cv.test;
dsTrain = ds(~idx,:);
dsTest = ds(idx,:);
testing = dsTest(1:end,1:end-1);
%save('test_set_AdaBoostM1.csv','testing') %saved my test set
%%
% Fitting the model and Prediction

t = templateTree('MaxNumSplits',100);
model1 = fitcensemble(dsTrain(1:end,1:end-1),dsTrain(:,end),'Method','AdaBoostM1','NumLearningCycles',11,'LearnRate',0.1,'Learners',t);
prediction1= predict(model1,testing);

%%
% Calculating accuracy,confusion matrix Precion,Recall and F1 score for model1
ms1 =(sum(prediction1==table2array(dsTest(:,end)))/size(dsTest,1))*100;%Accuracy in percentage

cm1= confusionchart(table2array(dsTest(:,end)),prediction1); %plot Confusion matrix chart for classification problem
%savefig('ConfusionMat AdaBoostM1 Before Hyper perameter tuning.fig');% saves confusion matrix before hyperparameter tuning
CM = confusionmat(table2array(dsTest(:,end)),prediction1); % Computes confusion matrix
TN1 = CM(1,1); % True negative from confusion matrix
FP1 = CM(1,2); % False Positive from confusion matrix
FN1 = CM(2,1); % False Negative from confusion matrix
TP1 = CM(2,2); % True Positive from confusion matrix

precision1 = TP1/(TP1+FP1); % calculating Precision   

recall1 = TP1/(TP1+ FN1);  % Calculating recall

f1score_1 = 2*((precision1*recall1)/(precision1+recall1)) ; % Calculating the F1 score

%%
%Hyperparameter tuning
MaxSplits = [100 500 1000 1500 2000 3000];
NumLrnCycl = [100 150 200];%159
LearRat = [0.1 0.05 0.01];%0.01

for  M= MaxSplits
    for N = NumLrnCycl
        for L = LearRat
            t1 = templateTree('MaxNumSplits',M);
            best_model_hyp1 = fitcensemble(dsTrain(1:end,1:end-1),dsTrain(:,end),'Method','AdaBoostM1','NumLearningCycles',N,'LearnRate',L,'Learners',t1);
            prediction_hyp2= predict(best_model_hyp1,testing);
            Acc_hyp =(sum(prediction_hyp2==table2array(dsTest(:,end)))/size(dsTest,1))*100;
            fprintf('accuracy of model when Maxnumber of split [%d] ,NumLearningCycle [%d] and LearnersRate [%f] is',M,N,L)
            max(Acc_hyp)
        end
    end
    
end
%%
% Checking the best AUC and accuracy by providing the best chosen parameters after hyper parameter tuning
% The highest AUC is choosen
T = table2array(dsTrain(:,end));
Y_Binary = logical(T);
t2 = templateTree('MaxNumSplits',2000);
best_model_AUC1 = fitcensemble(dsTrain(1:end,1:end-1),Y_Binary,'Method','AdaBoostM1','NumLearningCycles',150,'LearnRate',0.05,'Learners',t2);
prediction_AUC= predict(best_model_AUC1 ,testing); 
Acc_AUC1 =(sum(prediction_AUC==table2array(dsTest(:,end)))/size(dsTest,1))*100;% accuracy calculated for the given parameters
[~,score_ada] = resubPredict(best_model_AUC1 );
class(best_model_AUC1 )
[Xada,Yada,Tada,AUCada] = perfcurve(Y_Binary,score_ada(:,best_model_AUC1 .ClassNames),'true');%AUC calculated for the given parameters
% The best parameter selected MaxNumSplits 2000, NumLearningCycles 150 , LearnRate 0.05
%% 
% Fitting the Best model  and prediction
t3 = templateTree('MaxNumSplits',2000);
best_model1 = fitcensemble(dsTrain(1:end,1:end-1),dsTrain(:,end),'Method','AdaBoostM1','NumLearningCycles',150,'LearnRate',0.05,'Learners',t3);
%save('Best_model_AdaBoostM1.mat','best_model1');
prediction2= predict(best_model1,testing);
%%
% Calculating accuracy,confusion matrix Precion,Recall and F1 score for best model
ms2 =(sum(prediction2==table2array(dsTest(:,end)))/size(dsTest,1))*100;%Accuracy in percentage

cm2= confusionchart(table2array(dsTest(:,end)),prediction2); %plot Confusion matrix chart for classification problem
%savefig('ConfusionMat AdaBoostM1 After Hyper perameter tuning.fig');% saves confusion matrix after hyperparameter tuning
c = confusionmat(table2array(dsTest(:,end)),prediction2); % Computes confusion matrix for best model
TN2 = c(1,1) ;% True negative from confusion matrix
FP2 = c(1,2); % False Positive from confusion matrix
FN2 = c(2,1); % False Negative from confusion matrix
TP2 = c(2,2); % True Positive from confusion matrix

precision2 = TP2/(TP2+FP2);   % calculating Precision for best model

recall2 = TP2/(TP2+ FN2);   % Calculating recall for best model

f1score_2 = 2*((precision2*recall2)/(precision2+recall2)) ; % Calculating F1 score for best model

sensitivity = recall2;
TPR = sensitivity;% True Positive Rate for best model

specificity = TN1/(TN1 +FP1);
FPR = (1- specificity);% False Positive Rate for best model

%%
% calculated accuracy, f1 score, precision and recall between model1 and best_model1 for AdaboostM1

% accuracy best model1:91.6550             accuracy model 1 :93.7938  
% f1score_2 = 0.2609                      f1score_1 = 0.3113
% precision2 = 0.3307                      precision1 = 0.6452
% recall2 = 0.2154                         recall1 = 0.2051
% Specificity = 0.9917
% TPR(Sensitivity) = 0.2154
% FPR = 0.0083