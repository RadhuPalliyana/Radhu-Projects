
%checking rustboost............. AUC and ROC********************************

close all; clear all; clc;
ds = readtable('Bank Marketing clean data preprocessed Final.csv','PreserveVariableNames',true);
cv = cvpartition(size(ds,1),"Holdout",0.3);
idx= cv.test;
dsTrain = ds(~idx,:);
dsTest = ds(idx,:);
testing = dsTest(1:end,1:end-1);

T = table2array(dsTrain(:,end));
Y_Binary = logical(T);
%%
%Naive Bayes
model1 = fitcnb(dsTrain(1:end,1:end-1),Y_Binary);
[~,score_cnb] = resubPredict(model1);
class(model1)
[Xcnb,Ycnb,Tcnb,AUCcnb] = perfcurve(Y_Binary,score_cnb(:,model1.ClassNames),'true');
%prediction1= predict(model1,testing);
%cm1= confusionchart(table2array(dsTest(:,end)),prediction1);

%%
% Decision Tree
model2= fitctree(dsTrain(1:end,1:end-1),Y_Binary);
[~,score_tre] = resubPredict(model2);
class(model2)
[Xtre,Ytre,Ttre,AUCtre] = perfcurve(Y_Binary,score_tre(:,model2.ClassNames),'true');
%view(model2,'Mode','graph')
%prediction2= predict(model2,testing);
%cm2= confusionchart(table2array(dsTest(:,end)),prediction2);

%%
% RUSBOOST
t = templateTree('MaxNumSplits',2000);
model3 = fitcensemble(dsTrain(1:end,1:end-1),Y_Binary,'Method','RUSBoost',...
    'NumLearningCycles',150,'LearnRate',0.05,'Learners',t);
[~,score_rus] = resubPredict(model3);
class(model3)
[Xrus,Yrus,Trus,AUCrus] = perfcurve(Y_Binary,score_rus(:,model3.ClassNames),'true');
%prediction3= predict(model3,testing);
%cm3= confusionchart(table2array(dsTest(:,end)),prediction3);


%%
%AdaBoostM1

t = templateTree('MaxNumSplits',2000);
model4 = fitcensemble(dsTrain(1:end,1:end-1),Y_Binary,'Method','AdaBoostM1',...
    'NumLearningCycles',150,'LearnRate',0.05,'Learners',t);
[~,score_ada] = resubPredict(model4);
class(model4)
[Xada,Yada,Tada,AUCada] = perfcurve(Y_Binary,score_ada(:,model4.ClassNames),'true');
%prediction4= predict(model4,testing);
%cm4= confusionchart(table2array(dsTest(:,end)),prediction4);

%%
%SVM
model5 = fitcsvm(dsTrain(1:end,1:end-1),Y_Binary,'KernelFunction','gaussian','Standardize','on');
[~,score_svm] = resubPredict(model5);
class(model5)
[Xsvm,Ysvm,Tsvm,AUCsvm] = perfcurve(Y_Binary,score_svm(:,model5.ClassNames),'true');
%prediction5= predict(model5,testing);
%cm5= confusionchart(table2array(dsTest(:,end)),prediction5);

%%
%plotting ROC curve between AdaBoostM1,SVM,RUSBoost,Decision Tee and Naive Bayes
plot(Xada,Yada)
hold on
plot(Xsvm,Ysvm)
plot(Xrus,Yrus)
plot(Xtre,Ytre)
plot(Xcnb,Ycnb)
legend('AdaBoostM1','SVM','RUSBoost','Decision Tree','Naive Bayes','Location','Best')
xlabel('False positive rate'); ylabel('True positive rate');%ie  Xlabel is Precision ylabel is Recall
title('ROC Curves between AdaBoostM1,SVM,RusB,DT and NB')
hold off
savefig('Different Model comparision AUC_ROC curve.fig')% save AUC-ROC curve for AdaBoostM1,SVM,RUSBoost,Decision Tree,Naive Bayes