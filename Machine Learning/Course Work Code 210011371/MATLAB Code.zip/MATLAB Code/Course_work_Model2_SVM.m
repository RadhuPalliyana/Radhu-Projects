% Model 2 Support Vector Machine model implementation for classification problem
%% Load dataset
close all; clear all; clc;
ds = readtable('Bank Marketing clean data preprocessed Final.csv','PreserveVariableNames',true);
%%
%Test train split
n= size(ds,1);
cv = cvpartition(n,'Holdout',0.3);
idx= cv.test;
dsTrain = ds(~idx,:);
dsTest = ds(idx,:);
testing = dsTest(1:end,1:end-1);
save('test_set_SVM.csv','testing')  
%%
% Fitting the model and Prediction
model2 = fitcsvm(dsTrain(1:end,1:end-1),dsTrain(:,end),'KernelFunction','linear','Standardize','on');%92.5491
prediction1= predict(model2,testing);
%%
% Calculating accuracy,confusion matrix Precion,Recall and F1 score for model2
Acc1 =(sum(prediction1==table2array(dsTest(:,end)))/size(dsTest,1))*100;%Accuracy in percentage Absolute percentage error (Magnitude of relative error MRE)

cm1= confusionchart(table2array(dsTest(:,end)),prediction1);%plot Confusion matrix chart for classification problem
savefig('ConfusionMat SVM Before Hyper perameter tuning.fig'); % saves confusion matrix before hyperparameter tuning
CM = confusionmat(table2array(dsTest(:,end)),prediction1); % Computes confusion matrix
TN1 = CM(1,1); % True negative from confusion matrix
FP1 = CM(1,2); % False Positive from confusion matrix
FN1 = CM(2,1); % False Negative from confusion matrix
TP1 = CM(2,2); % True Positive from confusion matrix

precision1 = TP1/(TP1+FP1); % calculating Precision

recall1 = TP1/(TP1+ FN1);   % Calculating recall

f1score_1 = 2*((precision1*recall1)/(precision1+recall1)) ; % Calculating the F1 score
%%
%Hyperparameter tuning
KernFun = {'polynomial', 'linear' , 'gaussian'};
for  K = KernFun
    best_model_hyp2 = fitcsvm(dsTrain(1:end,1:end-1),dsTrain(:,end),'KernelFunction',K{1},'Standardize','on');
    prediction_hyp2= predict(best_model_hyp2,testing);
    Acc_hyp =(sum(prediction_hyp2==table2array(dsTest(:,end)))/size(dsTest,1))*100;
    max(Acc_hyp)
end
%%
%Checking the best AUC and accuracy by providing the best chosen parametersafter hyper parameter tuning.
% The highest AUC is choosen
T = table2array(dsTrain(:,end));
Y_Binary = logical(T);
best_model_AUC2 = fitcsvm(dsTrain(1:end,1:end-1),Y_Binary,'KernelFunction','gaussian','Standardize','on');        
prediction_AUC2= predict(best_model_AUC2,testing);            
Acc_AUC2 =(sum(prediction_AUC2==table2array(dsTest(:,end)))/size(dsTest,1))*100;  % accuracy calculated for the given parameters
[~,score_ada] = resubPredict(best_model_AUC2);
class(best_model_AUC2)
[Xada,Yada,Tada,AUCada] = perfcurve(Y_Binary,score_ada(:,best_model_AUC2.ClassNames),'true');%AUC calculated for the given parameters
% The best parameters chosen are Kernal function : gaussian
%% 
% Fitting the Best model  and prediction
best_model2 = fitcsvm(dsTrain(1:end,1:end-1),dsTrain(:,end),'KernelFunction','gaussian','Standardize','on');
save('best_model_SVM.mat','best_model2')
prediction2= predict(best_model2,testing);

%%
% Calculating accuracy,confusion matrix Precion,Recall and F1 score for best model
Acc2 =(sum(prediction2==table2array(dsTest(:,end)))/size(dsTest,1))*100; %Accuracy in percentage

cm2 = confusionchart(table2array(dsTest(:,end)),prediction2); %plot Confusion matrix chart for classification problem
savefig('ConfusionMat SVM After Hyper perameter tuning.fig');% saves confusion matrix after hyperparameter tuning

c = confusionmat(table2array(dsTest(:,end)),prediction2); % Computes confusion matrix for best model

TN2 = c(1,1); % True negative from confusion matrix
FP2 = c(1,2); % False Positive from confusion matrix
FN2 = c(2,1); % False Negative from confusion matrix
TP2 = c(2,2); % True Positive from confusion matrix

precision2 = TP2/(TP2+FP2);  % calculating Precision for best model 

recall2 = TP2/(TP2+ FN2);    % Calculating recall for best model

f1score_2 = 2*((precision2*recall2)/(precision2+recall2)) ;  % Calculating the F1 score for best model

sensitivity = recall2;
TPR = sensitivity;% True Positive Rate for best model

specificity = TN1/(TN1 +FP1);
FPR = (1- specificity);% False Positive Rate for best model

%%
% accuracy , f1 score, precision and recall between model2 and best_model2
% accuracy best model2: 93.1101         accuracy model 2 : 93.8464
% f1score_2 = 0.1007                    f1score_1 = 0.2822
% precision2 = 0.5366                   precision1 = 0.7419
% recall2 = 0.0556                      recall1 = 0.1742
% Specificity =0.0556
% TPR(Sensitivity) =0.0556
% FPR = 0.0045