% Best model and ROC curve ploting between AdaboostM1 and SVM
%% Load dataset
close all; clear all; clc;
ds = readtable('Bank Marketing clean data preprocessed Final.csv','PreserveVariableNames',true);
%%
%Test train split
n= size(ds,1);
cv = cvpartition(n,'Holdout',0.3);
idx= cv.test;
dsTrain = ds(~idx,:);
dsTest = ds(idx,:);
testing = dsTest(1:end,1:end-1);

%%
% best model1 Receiver operating characteristic curve and Area under curve for AdaboostM1
T = table2array(dsTrain(:,end));
Y_Binary = logical(T);
t = templateTree('MaxNumSplits',2000);
best_model1 = fitcensemble(dsTrain(1:end,1:end-1),Y_Binary,'Method','AdaBoostM1','NumLearningCycles',150,'LearnRate',0.05,'Learners',t);
[~,score_ada] = resubPredict(best_model1);
class(best_model1)
[Xada,Yada,Tada,AUCada] = perfcurve(Y_Binary,score_ada(:,best_model1.ClassNames),'true');
%%
% best model1 Receiver operating characteristic curve and Area under curve for Classification decision tree
best_model2 = fitcsvm(dsTrain(1:end,1:end-1),Y_Binary,'KernelFunction','gaussian','Standardize','on');
[~,score_svm] = resubPredict(best_model2);
class(best_model2)
[Xsvm,Ysvm,Tsvm,AUCsvm] = perfcurve(Y_Binary,score_svm(:,best_model2.ClassNames),'true');

%%
%Ploting ROC curves for AdaBoostM1 and SVM
plot(Xada,Yada)
hold on
plot(Xsvm,Ysvm)
legend('AdaBoostM1','SVM','Location','Best')
xlabel('False positive rate'); ylabel('True positive rate');%ie  Xlabel is Precision ylabel is Recall
title('ROC Curves for AdaBoostM1 and SVM')
hold off
savefig('Best Model AdaBoostM1 and SVM AUC_ROC curve.fig') % save AUC-ROC curve for AdaBoostM1 and SVM
%AUCsvm = 0.7862 AUCada = 0.9960